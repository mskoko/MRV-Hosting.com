var Ping = require('./src/ping');
module.exports = Ping;
